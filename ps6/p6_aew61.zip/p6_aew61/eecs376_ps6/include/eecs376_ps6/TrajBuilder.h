#pragma once
#ifndef EECS376_PS6_TRAJ_BUILDER_H
#define EECS376_PS6_TRAJ_BUILDER_H

// SYSTEM INCLUDES
#include <queue>
#include <math.h>
#include <stdlib.h>
#include <string>
#include <vector>

// ROS INCLUDES

// C++ PROJECT INCLUDES
#include "eecs376_ps6/types.h"


const double default_a_max = 0.5; //1m/sec^2
const double default_alpha_max = 0.2; //1 rad/sec^2
const double default_v_max = 1.0; //1 m/sec
const double default_omega_max = 1.0; //1 rad/sec
const double default_path_move_tol = 0.01; // if path points are within 1cm, fuggidaboutit
const double default_dt=0.02;


class TrajBuilder
{
public:

    TrajBuilder();

    virtual ~TrajBuilder();

    void set_dt(const double dt);

    void set_a_max(const double a_max);

    void set_v_max(const double v_max);

    void set_alpha_max(const double alpha_max);

    void set_omega_max(const double omega_max);

    void set_path_move_tol(const double tol);

    const double min_dang(const double dang);
    const double sat(const double x);
    const double sign(const double x);
    const double convert_planar_quaternion_to_phi(const quaternion_t& q);
    const quaternion_t convert_planar_phi_to_quaternion(const double phi);

    pose_stamped_t xyphi_to_pose_stamped(const double x, const double y, const double phi);

    //here are the main traj-builder fncs:
    void build_trapezoidal_spin_traj(const pose_stamped_t start_pose,
                                     const pose_stamped_t end_pose,
                                     std::vector<odom_t>& vec_of_states);

    void build_triangular_spin_traj(const pose_stamped_t start_pose,
                                    const pose_stamped_t end_pose,
                                    std::vector<odom_t>& vec_of_states);

    void build_spin_traj(const pose_stamped_t start_pose,
                         const pose_stamped_t end_pose,
                         std::vector<odom_t>& vec_of_states);

    void build_travel_traj(const pose_stamped_t start_pose,
                           const pose_stamped_t end_pose,
                           std::vector<odom_t>& vec_of_states);

    void build_trapezoidal_travel_traj(const pose_stamped_t start_pose,
                                       const pose_stamped_t end_pose,
                                       std::vector<odom_t>& vec_of_states);

    void build_triangular_travel_traj(const pose_stamped_t start_pose,
                                      const pose_stamped_t end_pose,
                                      std::vector<odom_t>& vec_of_states);

    void build_point_and_go_traj(const pose_stamped_t start_pose,
                                 const pose_stamped_t end_pose,
                                 std::vector<odom_t>& vec_of_states);

    void build_braking_traj(const pose_stamped_t current_pose, std::vector<odom_t>& vec_of_states,
                            const int current_pos_in_vec);

protected:
private:

    double _dt;
    double _a_max;
    double _v_max;
    double _alpha_max;
    double _omega_max;
    double _path_move_tol;

    twist_t _halt_twist;

};

#endif // end of EECS376_PS6_TRAJ_BUILDER_H
