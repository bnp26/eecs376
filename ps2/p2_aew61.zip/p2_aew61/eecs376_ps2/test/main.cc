// SYSTEM INCLUDES
#include <gtest/gtest.h>

// C++ PROJECT INCLUDES


int main(int argc, char** argv)
{
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
