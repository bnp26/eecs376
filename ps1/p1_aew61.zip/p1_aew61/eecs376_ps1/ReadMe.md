Programming Assignment 1: Open Loop Commander

This ROS package produces a single executable named eecs376_ps1_node that will direct a robot starting at the
initial starting position in stdr_simulator to the upper left hand corner of the map. It uses a pre-programmed
path that cost the lives of many undergraduate developers to make...so use it well.
